# Scones Unlimited — Event-Driven Image Classification Workflow

An end-to-end machine learning workflow that classifies bicycle vs. motorcycle
images, filters low-confidence predictions, and notifies operations on failure.
Built with **SageMaker**, **AWS Lambda**, **Step Functions**, **Model Monitor**,
and **SNS + EventBridge**.

---

## Project Overview

Scones Unlimited needs to tell bicycles and motorcycles apart to route delivery
drivers. This project builds that capability end to end:

1. **Data staging** — Extracted CIFAR-100, filtered it down to bicycles and
   motorcycles, reshaped the images to PNGs, and synced train/test sets and
   manifest files to S3.
2. **Model training** — Trained a binary image classifier with the SageMaker
   `image-classification` algorithm.
3. **Deployment** — Deployed the model to a real-time SageMaker endpoint with
   `DataCaptureConfig` enabled for Model Monitor.
4. **Orchestration** — Chained three Lambda functions (serialize → classify →
   filter) in a Step Function that fans out over batches of images. The final
   Lambda fails loudly when confidence is below `0.93`.
5. **Monitoring** — Downloaded the captured inference data and visualized
   confidence over time and its distribution.
6. **Failure notifications** *(stretch goal)* — Added an EventBridge rule and
   SNS topic so the operations team is emailed whenever the workflow fails.

---

## Architecture

```
  CIFAR-100 ──▶ ETL ──▶ S3 (train/ test/ manifests)
                          │
                          ▼
                 SageMaker training job
                          │
                          ▼
          Real-time endpoint + DataCaptureConfig
                          │
   S3 image keys ──▶ Step Function (Map fan-out)
                          ├─ serializeImageData   (Lambda)
                          ├─ classifyImageData    (Lambda → endpoint)
                          └─ classifyInference    (Lambda, threshold 0.93)
                          │
        On FAILED ──▶ EventBridge ──▶ SNS ──▶ 📧
                          │
                          ▼
        Data capture ──▶ Model Monitor ──▶ visualizations
```

---

## Components

| Component | Purpose |
|---|---|
| `starter.ipynb` — Data staging | Extracts CIFAR-100, filters to bicycle/motorcycle, reshapes images, syncs to S3 |
| `starter.ipynb` — Model training and Deployment | Runs training job and Deploys the model  with data capture|
| `starter.ipynb` — Testing and Evaluation | Invokes the Step Function, downloads capture data, builds visualizations |
| `image-classification-job-20261105094052` （Training job） | Trains the binary bicycle/motorcycle model |
| `img-classifier-endpoint` (Endpoint) | Real-time SageMaker endpoint with data capture |
| `serializeImageData` (Lambda) | Downloads image from S3, base64-encodes it |
| `classifyImageData` (Lambda) | Calls the endpoint, returns inferences |
| `classifyInference` (Lambda) | Rejects predictions below `THRESHOLD = 0.93` |
| `img-classification-step-function` (Step Function) | Step Function with `Map` batch fan-out |
| EventBridge rule + SNS topic & subscription| Email notifications on failure |

---

## Screenshots

### Step Function — UI Design

![Step Function UI Design](screenshots/Step-Function-UI.png)

### Step Function — Execution Detail

![Step Function Execution Detail](screenshots/Step-Function-Execution.png)

![Step Function Execution Input Output](screenshots/Step-Function-Input-output.png)

### SNS topic and subscription

![SNS topic and subscription](screenshots/SNS-Topic-Subscriptions.png)

### EventBridge rule

![EventBridge rule](screenshots/EventBridge-Rule.png)

### Email notification received

![Email notification](screenshots/Notification-Email.png)

### Model Monitor — observed inferences

Max confidence over time; red points fall below the production threshold
(`0.93`), marked by the dashed line.

![Observed inferences](screenshots/Model-Monitor.png)

### Model Monitor — confidence distribution

![Confidence distribution](screenshots/Model-Monitor-Hist.png)

---

## Stretch Goal: Batch Fan-Out with Map

The workflow processes multiple images in parallel using a `Map` state.

- Input: `{"keys": [...]}` — an array of image objects.
- `Items: {% $states.input.keys %}` iterates over the array.
- Each iteration runs independently; failures are surfaced per-iteration.
- The three Lambdas required **no code changes** — they still process a single
  image, and `Map` handles the fan-out.

---

## Stretch Goal: Failure Notification via SNS

```
Step Function FAILED → EventBridge Rule → SNS Topic → Email
```

**Gotcha worth noting:** Distributed Map child executions use a
`stateMachineArn` with a `/ProcessBatch` suffix, e.g.

```
arn:aws:states:us-east-1:518592339750:stateMachine:img-classification-step-function/ProcessBatch
```

A rule matching only the parent state-machine ARN will **not** match
child-execution failures.

---

## Results

| Scenario | Outcome |
|---|---|
| All images above threshold (0.93) | Execution **SUCCEEDED** |
| Any image below threshold | That iteration **FAILED**; email sent via SNS |

---
