import json
import boto3
import base64

####################### function 1: Serialize Image ##################
s3 = boto3.client('s3')

def lambda_handler_serializer(event, context):
    """A function to serialize target data from S3"""
    
    # Get the s3 address from the Step Function event input
    key = event['s3_key']## TODO: fill in
    bucket = event['s3_bucket']## TODO: fill in
    
    # Download the data from s3 to /tmp/image.png
    ## TODO: fill in
    s3.download_file(bucket, key, '/tmp/image.png')

    # We read the data from a file
    with open("/tmp/image.png", "rb") as f:
        image_data = base64.b64encode(f.read())

    # Pass the data back to the Step Function
    print("Event:", event.keys())
    return {
        'statusCode': 200,
        'body': {
            "image_data": image_data,
            "s3_bucket": bucket,
            "s3_key": key,
            "inferences": []
        }
    }

####################### function 2: Classify Image ##################

ENDPOINT = 'img-classifier-endpoint' ## TODO: fill in
runtime = boto3.client('sagemaker-runtime')

def lambda_handler_classify(event, context):

    # Decode the image data
    image = base64.b64decode(event['image_data'])## TODO: fill in
   
    # Make a prediction:
    response = runtime.invoke_endpoint( ## TODO: fill in
        EndpointName=ENDPOINT,
        ContentType='image/png',
        Body=image
    )
    # We return the data back to the Step Function    
    inference = json.loads(response['Body'].read().decode('utf-8'))
    return {
        'statusCode': 200,
        'body': {
            "image_data": event['image_data'],
            "s3_bucket": event['s3_bucket'],
            "s3_key": event['s3_key'],
            "inference": inference
        }
    }

####################### function 3: Inference Threshold ##################

THRESHOLD = .93

def lambda_handler_inference(event, context):
    
    # Grab the inferences from the event
    inferences = event.get('inference')
    if not inferences:
        raise Exception('NO_INFERENCE_DATA')
    
    # Check if any values in our inferences are above THRESHOLD
    meets_threshold = max(float(x) for x in inferences) >= THRESHOLD ## TODO: fill in
    
    # If our threshold is met, pass our data back out of the
    # Step Function, else, end the Step Function with an error
    if meets_threshold:
        pass
    else:
        raise Exception("THRESHOLD_CONFIDENCE_NOT_MET")

    return {
        'statusCode': 200,
        'body': json.dumps(event)
    }
